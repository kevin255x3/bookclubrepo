import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';

//  provides dropdown for filtering books by category
//  fetches categories from the API and handles category selection (triggers filter action on selection)
const CategoryFilter = ({ selectedCategory, onCategoryChange }) => {
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // fetch categories when component mounts
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                setLoading(true);
                const response = await axios.get(`${config.API_URL}/api/categories`);
                setCategories(response.data);
                setLoading(false);
            } catch (err) {
                setError('Error loading categories');
                setLoading(false);
                console.error('Error fetching categories:', err);
            }
        };

        fetchCategories();
    }, []);

    // handle change in the category dropdown
    const handleChange = (e) => {
        onCategoryChange(e.target.value);
    };

    // show loading (indicator), error or categories dropdown
    if (loading) return <div>Loading categories...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <div className="category-filter">
            <label htmlFor="category-select">Filter by Category:</label>
            <select
                id="category-select"
                value={selectedCategory}
                onChange={handleChange}
                className="category-select"
            >
                <option value="">All Categories</option>
                {categories.map(category => (
                    <option key={category.id} value={category.id}>
                        {category.name} ({category.book_count})
                    </option>
                ))}
            </select>
        </div>
    );
};

export default CategoryFilter;