import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import config from '../config';

// book detail - displays book information for single book( as much as possible from the api)
const BookDetail = () => {
    // get book id from url params
    const { id } = useParams();
    const navigate = useNavigate();

    // state for book data and loading status
    const [book, setBook] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // fetch book details when component mounts
    useEffect(() => {
        const fetchBook = async () => {
            try {
                setLoading(true);
                const response = await axios.get(`${config.API_URL}/api/books/${id}`);
                setBook(response.data);
                setLoading(false);
            } catch (err) {
                setError('Error fetching book details.');
                setLoading(false);
                console.error('Error fetching book:', err);
            }
        };

        fetchBook();
    }, [id]);

    // handle book deletion (with confirmation)
    const handleDelete = async () => {
        if (window.confirm('Are you sure you want to delete this book?')) {
            try {
                await axios.delete(`${config.API_URL}/api/books/${id}`);
                navigate('/');
                // redirect to home page after deletion
            } catch (err) {
                setError('Error deleting book. Please try again.');
                console.error('Error deleting book:', err);
            }
        }
    };

    // show loading, error or book details
    if (loading) return <div className="loading">Loading book details...</div>;
    if (error) return <div className="error">{error}</div>;
    if (!book) return <div className="not-found">Book not found</div>;

    return (

        <div className="book-detail">
            {/* title and action buttons */}
            <div className="book-detail-header">
                <h1>{book.title}</h1>
                <div className="book-actions">
                    <Link to="/" className="btn btn-secondary">Back to List</Link>
                    <Link to={`/edit-book/${book.id}`} className="btn btn-warning">Edit Book</Link>
                    <button onClick={handleDelete} className="btn btn-danger">Delete Book</button>
                </div>
            </div>

            {/* content with cover image and details */}
            <div className="book-detail-content">
                <div className="book-cover">
                    {book.cover_image ? (
                        <img
                            src={`${config.UPLOADS_URL}/${book.cover_image}`}
                            alt={`Cover of ${book.title}`}
                        />
                    ) : (
                        <div className="placeholder-cover"><span>text only</span></div>
                    )}
                </div>

                <div className="book-info">
                    {/* book metadata */}
                    <div className="info-row">
                        <span className="label">Author:</span>
                        <span className="value">{book.author}</span>
                    </div>

                    <div className="info-row">
                        <span className="label">Category:</span>
                        <span className="value">{book.category_name || 'Uncategorized'}</span>
                    </div>

                    {book.publication_year && (
                        <div className="info-row">
                            <span className="label">Publication Year:</span>
                            <span className="value">{book.publication_year}</span>
                        </div>
                    )}

                    <div className="info-row">
                        <span className="label">Added:</span>
                        <span className="value">
                            {new Date(book.created_at).toLocaleDateString()}
                        </span>
                    </div>

                    {/* description */}
                    {book.description && (
                        <div className="description">
                            <h3>Description</h3>
                            <p>{book.description}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default BookDetail;