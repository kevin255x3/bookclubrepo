import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// import components
import BookList from './components/BookList';
import BookDetail from './components/BookDetail';
import BookForm from './components/BookForm';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>bookclub</h1>
        </header>

        <main className="container">
          <Routes>
            {/* home */}
            <Route path="/" element={<BookList />} />

            {/* details */}
            <Route path="/books/:id" element={<BookDetail />} />

            {/* add new book form */}
            <Route path="/add-book" element={<BookForm isEditing={false} />} />

            {/* exsisting book */}
            <Route path="/edit-book/:id" element={<BookForm isEditing={true} />} />
          </Routes>
        </main>

        <footer className="App-footer">
          <p>dialogue</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;